package com.example.fivestar.Constant;

public enum DeviceType {
    NORMALLY_CLOSE,
    NORMALLY_OPEN,
    TOGGLE,SET,RESET,DELAY
}
