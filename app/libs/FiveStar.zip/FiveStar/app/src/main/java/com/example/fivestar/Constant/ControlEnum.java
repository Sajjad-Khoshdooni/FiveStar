package com.example.fivestar.Constant;

public enum ControlEnum {
    INTERNET,
    BLUETOOTH
}
