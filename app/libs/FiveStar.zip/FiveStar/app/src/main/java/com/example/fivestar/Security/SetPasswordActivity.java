package com.example.fivestar.Security;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.fivestar.R;

public class SetPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_password);
    }
}